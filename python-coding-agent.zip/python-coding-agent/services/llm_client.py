import openai
from config import Config
from core.utils.logger import logger

class LLMClient:
    def __init__(self):
        self.client = openai.OpenAI(api_key=Config.LLM_API_KEY)
        self.model = Config.LLM_MODEL
    
    def generate_text(self, prompt: str, system_message: str = None) -> str:
        """Generate text using OpenAI API"""
        messages = []
        
        if system_message:
            messages.append({"role": "system", "content": system_message})
        
        messages.append({"role": "user", "content": prompt})
        
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=Config.LLM_TEMPERATURE,
                max_tokens=Config.LLM_MAX_TOKENS
            )
            return response.choices[0].message.content.strip()
        except Exception as e:
            logger.error(f"LLM request failed: {str(e)}")
            raise

# Singleton instance
llm_client = LLMClient()