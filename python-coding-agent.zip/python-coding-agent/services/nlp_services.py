import spacy
from config import Config
from core.utils.logger import logger

def load_spacy_model():
    """Load spaCy model with error handling"""
    try:
        nlp = spacy.load(Config.NLP_MODEL)
        logger.info(f"Loaded spaCy model: {Config.NLP_MODEL}")
        return nlp
    except OSError:
        logger.warning(f"Model {Config.NLP_MODEL} not found. Downloading...")
        spacy.cli.download(Config.NLP_MODEL)
        return spacy.load(Config.NLP_MODEL)
    except Exception as e:
        logger.error(f"Failed to load spaCy model: {str(e)}")
        raise

def extract_key_phrases(doc):
    """Extract key phrases from processed text"""
    return [chunk.text for chunk in doc.noun_chunks]

def extract_verbs(doc):
    """Extract main verbs from text"""
    return [token.lemma_ for token in doc if token.pos_ == "VERB"]