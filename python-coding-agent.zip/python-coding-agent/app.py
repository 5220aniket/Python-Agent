from flask_cors import CORS
from flask import Flask, request, jsonify, render_template
from core.agents.coding_agent import handle_task
from config import Config, setup_directories
import os
import logging
from datetime import datetime

app = Flask(__name__, 
            template_folder='templates',
            static_folder='templates/static')  # Add static folder configuration
CORS(app) 


# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create output directories
os.makedirs(Config.OUTPUT_DIR, exist_ok=True)
os.makedirs(Config.CODE_SNIPPETS_DIR, exist_ok=True)
os.makedirs(Config.LOGS_DIR, exist_ok=True)
os.makedirs(Config.SESSIONS_DIR, exist_ok=True)

@app.route('/')
def index():
    """Render the main application page with CSS/assets"""
    logger.info("Serving index page")
    return render_template('index.html')

@app.route('/api/process', methods=['POST'])
def process_query():
    """
    Process natural language queries through the full pipeline
    """
    start_time = datetime.now()
    
    data = request.json
    user_query = data.get('query', '').strip()
    session_id = data.get('session_id', 'default_session')
    
    # Create session directory
    session_dir = os.path.join(Config.SESSIONS_DIR, session_id)
    os.makedirs(session_dir, exist_ok=True)
    
    if not user_query:
        logger.warning("Empty query received")
        return jsonify({"error": "Query is required"}), 400
    
    try:
        logger.info(f"Processing query: {user_query}")
        
        # Save original query
        with open(os.path.join(session_dir, "query.txt"), "w") as f:
            f.write(user_query)
        
        # Execute the full pipeline
        response = handle_task(user_query)
        
        # Save generated response
        with open(os.path.join(session_dir, "response.md"), "w") as f:
            f.write(response)
        
        # Calculate processing time
        processing_time = (datetime.now() - start_time).total_seconds()
        logger.info(f"Query processed in {processing_time:.2f} seconds")
        
        return jsonify({
            "response": response,
            "processing_time": processing_time,
            "status": "success"
        })
    except Exception as e:
        logger.error(f"Error processing query: {str(e)}", exc_info=True)
        return jsonify({
            "error": f"Internal server error: {str(e)}",
            "status": "error"
        }), 500

@app.route('/new-session', methods=['POST'])
def new_session():
    """Create a new session ID for isolating user interactions"""
    session_id = f"session_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    session_dir = os.path.join(Config.SESSIONS_DIR, session_id)
    os.makedirs(session_dir, exist_ok=True)
    return jsonify({"session_id": session_id})

if __name__ == '__main__':
    logger.info("Starting Python Coding Agent")
    logger.info(f"Output directory: {Config.OUTPUT_DIR}")
    logger.info(f"Using LLM model: {Config.NLP_MODEL}")
    logger.info(f"Static files served from: {app.static_folder}")
    app.run(host='0.0.0.0', port=5000, debug=True)
    
setup_directories()