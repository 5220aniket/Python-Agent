// GSAP Animations
document.addEventListener('DOMContentLoaded', () => {
    // Animate hero text
    gsap.from('.animated-text', {
        duration: 1,
        y: 50,
        opacity: 0,
        ease: 'power3.out'
    });
    
    // Animate subtitle
    gsap.from('.subtitle', {
        duration: 1,
        y: 30,
        opacity: 0,
        delay: 0.3,
        ease: 'power3.out'
    });
    
    // Animate feature cards
    gsap.from('.feature-card', {
        duration: 0.8,
        y: 50,
        opacity: 0,
        stagger: 0.2,
        delay: 0.5,
        ease: 'back.out(1.7)'
    });
    
    // Animate chat window
    gsap.from('.chat-window', {
        duration: 1,
        y: 50,
        opacity: 0,
        delay: 0.8,
        ease: 'power3.out'
    });
    
    // Hover animations for buttons
    const buttons = document.querySelectorAll('.btn, .tool-btn');
    buttons.forEach(button => {
        button.addEventListener('mouseenter', () => {
            gsap.to(button, {
                duration: 0.3,
                y: -3,
                boxShadow: '0 10px 20px rgba(0,0,0,0.2)',
                ease: 'power2.out'
            });
        });
        
        button.addEventListener('mouseleave', () => {
            gsap.to(button, {
                duration: 0.3,
                y: 0,
                boxShadow: '0 0 0 rgba(0,0,0,0)',
                ease: 'power2.out'
            });
        });
    });
});