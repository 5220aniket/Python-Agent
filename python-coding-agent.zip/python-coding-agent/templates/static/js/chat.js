document.addEventListener('DOMContentLoaded', () => {
    const chatMessages = document.getElementById('chat-messages');
    const userInput = document.getElementById('user-input');
    const sendButton = document.getElementById('send-button');
    
    // Focus input on load
    userInput.focus();
    
    // Send message on button click
    sendButton.addEventListener('click', sendMessage);
    
    // Send message on Enter (without Shift)
    userInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });
    
    function sendMessage() {
        const message = userInput.value.trim();
        if (!message) return;
        
        // Add user message to chat
        addMessage('user', message);
        userInput.value = '';
        userInput.style.height = 'auto';
        
        // Show loading indicator
        const loadingMessage = addMessage('agent', 'Thinking...', true);
        
        // Send to backend
        fetch('/api/process', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ query: message })
        })
        .then(response => response.json())
        .then(data => {
            // Remove loading message
            loadingMessage.remove();
            
            if (data.status === 'success') {
                addMessage('agent', data.response);
            } else {
                addMessage('agent', `Error: ${data.error}`);
            }
        })
        .catch(error => {
            loadingMessage.remove();
            addMessage('agent', `Request failed: ${error.message}`);
        });
    }
    
    function addMessage(sender, text, isLoading = false) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${sender}`;
        
        const avatar = document.createElement('div');
        avatar.className = 'avatar';
        avatar.innerHTML = sender === 'agent' ? 
            '<i class="fas fa-robot"></i>' : 
            '<i class="fas fa-user"></i>';
        
        const content = document.createElement('div');
        content.className = 'content';
        
        const name = document.createElement('div');
        name.className = 'name';
        name.textContent = sender === 'agent' ? 'Code Assistant' : 'You';
        
        const textDiv = document.createElement('div');
        textDiv.className = 'text';
        
        if (isLoading) {
            const dots = document.createElement('div');
            dots.className = 'loading-dots';
            dots.innerHTML = '<div></div><div></div><div></div>';
            textDiv.appendChild(dots);
        } else {
            // Format code blocks with highlight.js if available
            if (text.includes('```python') && window.hljs) {
                const codeMatch = text.match(/```python\n([\s\S]*?)\n```/);
                if (codeMatch) {
                    const codeBlock = document.createElement('pre');
                    codeBlock.className = 'python';
                    codeBlock.textContent = codeMatch[1];
                    hljs.highlightElement(codeBlock);
                    
                    textDiv.appendChild(codeBlock);
                    
                    // Add explanation if present
                    const explanation = text.replace(/```python\n[\s\S]*?\n```/, '');
                    if (explanation.trim()) {
                        textDiv.appendChild(document.createTextNode(explanation));
                    }
                } else {
                    textDiv.textContent = text;
                }
            } else {
                textDiv.innerHTML = text;
            }
        }
        
        const timestamp = document.createElement('div');
        timestamp.className = 'timestamp';
        timestamp.textContent = 'Just now';
        
        content.appendChild(name);
        content.appendChild(textDiv);
        content.appendChild(timestamp);
        
        messageDiv.appendChild(avatar);
        messageDiv.appendChild(content);
        
        chatMessages.appendChild(messageDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;
        
        return messageDiv;
    }
});