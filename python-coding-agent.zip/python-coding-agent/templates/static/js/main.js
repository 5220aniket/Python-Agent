// Initialize animations and event listeners
document.addEventListener('DOMContentLoaded', () => {
    // Auto-resize textarea
    const textarea = document.getElementById('user-input');
    textarea.addEventListener('input', function() {
        this.style.height = 'auto';
        this.style.height = (this.scrollHeight) + 'px';
    });

    // Initialize tooltips
    const toolButtons = document.querySelectorAll('.tool-btn');
    toolButtons.forEach(button => {
        button.addEventListener('click', function() {
            const action = this.textContent.trim().toLowerCase();
            handleQuickAction(action);
        });
    });

    // Initialize animations
    initParticleAnimations();
});

function handleQuickAction(action) {
    const textarea = document.getElementById('user-input');
    let prefix = '';
    
    switch(action) {
        case 'generate':
            prefix = 'Generate Python code that ';
            break;
        case 'debug':
            prefix = 'Debug this Python code: \n';
            break;
        case 'explain':
            prefix = 'Explain this Python code: \n';
            break;
    }
    
    textarea.value = prefix + textarea.value;
    textarea.focus();
    textarea.dispatchEvent(new Event('input'));
}

function initParticleAnimations() {
    // Particles are animated via CSS, but we can add JS enhancements
    const particles = document.querySelectorAll('.code-particle');
    particles.forEach(particle => {
        particle.style.animationDelay = `${Math.random() * 5}s`;
    });
}