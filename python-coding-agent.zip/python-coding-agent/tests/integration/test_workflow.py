import pytest
from core.agents.coding_agent import handle_task

def test_full_workflow_code_generation():
    response = handle_task("Create a function to reverse a string")
    assert "def reverse_string" in response
    assert "return s[::-1]" in response

def test_full_workflow_debugging():
    response = handle_task("Fix this code: def multiply(a,b): return a + b")
    assert "def multiply(a, b)" in response
    assert "return a * b" in response

def test_full_workflow_explanation():
    response = handle_task("Explain list comprehensions in Python")
    assert "List comprehensions" in response
    assert "concise way" in response