import spacy
from core.modules.intent_detector import detect_intent

nlp = spacy.load("en_core_web_sm")

def test_detect_intent_code_generation():
    doc = nlp("Generate a function to calculate factorial")
    assert detect_intent(doc) == "CODE_GENERATION"

def test_detect_intent_debugging():
    doc = nlp("Fix this code: def add(a,b): return a - b")
    assert detect_intent(doc) == "DEBUGGING"

def test_detect_intent_explanation():
    doc = nlp("Explain how this Python decorator works")
    assert detect_intent(doc) == "EXPLANATION"

def test_detect_intent_default():
    doc = nlp("What's the weather today?")
    assert detect_intent(doc) == "CODE_GENERATION"