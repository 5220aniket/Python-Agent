import pytest
from core.modules.input_parser import parse_input

def test_parse_input_basic():
    assert parse_input("  Hello  World  ") == "Hello World"

def test_parse_input_special_chars():
    assert parse_input("This is a test!@#$%^&*()") == "This is a test!@#$%^&*()"

def test_parse_input_empty():
    assert parse_input("") == ""

def test_parse_input_multiple_spaces():
    assert parse_input("Too     many    spaces") == "Too many spaces"