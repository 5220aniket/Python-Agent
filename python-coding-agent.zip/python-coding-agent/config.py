import os
from dotenv import load_dotenv

load_dotenv()


def setup_directories():
    os.makedirs(Config.OUTPUT_DIR, exist_ok=True)
    os.makedirs(Config.CODE_SNIPPETS_DIR, exist_ok=True)
    os.makedirs(Config.LOGS_DIR, exist_ok=True)
    os.makedirs(Config.SESSIONS_DIR, exist_ok=True)
    


class Config:
    # Directory paths
    OUTPUT_DIR = "outputs"
    CODE_SNIPPETS_DIR = os.path.join(OUTPUT_DIR, "code_snippets")
    LOGS_DIR = os.path.join(OUTPUT_DIR, "logs")  # Add this line
    SESSIONS_DIR = os.path.join(OUTPUT_DIR, "sessions")  # And this line
    
    # NLP Settings
    NLP_MODEL = "en_core_web_md"
    
    # API provider selection
    API_PROVIDER = "deepseek"  # or "openai"
    
    # DeepSeek configuration
    DEEPSEEK_API_KEY = os.getenv("DEEPSEEK_API_KEY")
    DEEPSEEK_MODEL = "deepseek-coder"
    DEEPSEEK_BASE_URL = "https://api.deepseek.com/v1"
    
    # OpenAI configuration
    OPENAI_API_KEY = os.getenv("sk-f455f68b6f7247fd8d8415bab9dd96f4")
    OPENAI_MODEL = "gpt-4-turbo"
    LLM_TEMPERATURE = 0.7
    LLM_MAX_TOKENS = 1500
    
    # Logging
    LOG_LEVEL = "INFO"
    
    @property
    def llm_config(self):
        if self.API_PROVIDER == "deepseek":
            return {
                "api_key": self.DEEPSEEK_API_KEY,
                "base_url": self.DEEPSEEK_BASE_URL,
                "model": self.DEEPSEEK_MODEL
            }
        else:
            return {
                "api_key": self.OPENAI_API_KEY,
                "base_url": "https://api.openai.com/v1",
                "model": self.OPENAI_MODEL
            }