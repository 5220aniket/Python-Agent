import re
from core.utils.logger import logger

def parse_input(user_input: str) -> str:
    """Clean and normalize user input"""
    try:
        # Remove extra whitespace and special characters
        cleaned = re.sub(r'\s+', ' ', user_input).strip()
        logger.debug(f"Parsed input: '{user_input}' -> '{cleaned}'")
        return cleaned
    except Exception as e:
        logger.error(f"Input parsing error: {str(e)}")
        raise