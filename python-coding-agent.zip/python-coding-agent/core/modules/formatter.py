from core.utils.logger import logger

def format_output(code: str, intent: str) -> str:
    """Format the output based on intent"""
    try:
        if intent == "CODE_GENERATION":
            return f"```python\n{code}\n```"
        elif intent == "DEBUGGING":
            return f"**Fixed Code:**\n```python\n{code}\n```"
        elif intent == "EXPLANATION":
            return f"**Explanation:**\n{code}"
        else:
            return f"**Result:**\n```python\n{code}\n```"
    except Exception as e:
        logger.error(f"Formatting error: {str(e)}")
        return code