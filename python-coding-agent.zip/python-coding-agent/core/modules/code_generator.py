import openai
from config import Config
from core.utils.logger import logger

config = Config()
llm_config = config.llm_config

# Initialize client
client = openai.OpenAI(
    api_key=llm_config["api_key"],
    base_url=llm_config["base_url"]
)

def generate_code(doc, intent: str) -> str:
    """Generate code using selected API provider"""
    try:
        # System prompt based on intent
        if intent == "CODE_GENERATION":
            system = "You are an expert Python developer. Generate clean, efficient Python code."
        elif intent == "DEBUGGING":
            system = "You are a debugging assistant. Fix the Python code and explain the issue."
        else:
            system = "You are a technical explainer. Provide clear explanations with code examples."
        
        # Create prompt
        prompt = f"Task: {doc.text}\n\nProvide only the Python code solution."
        
        response = client.chat.completions.create(
            model=llm_config["model"],
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": prompt}
            ],
            temperature=0.7,
            max_tokens=1500
        )
        
        code = response.choices[0].message.content.strip()
        logger.debug(f"Generated code using {config.API_PROVIDER}:\n{code}")
        return code
    except Exception as e:
        logger.error(f"Code generation error: {str(e)}")
        return f"# Error: {str(e)}"