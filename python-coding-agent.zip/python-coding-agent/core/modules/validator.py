import ast
import subprocess
from core.utils.logger import logger
from config import Config
import os

def validate_code(code: str) -> str:
    """Validate and test generated code"""
    try:
        # Syntax validation
        ast.parse(code)
        logger.debug("Code syntax is valid")
        
        # Save code to file for execution
        snippet_path = os.path.join(Config.CODE_SNIPPETS_DIR, "temp_code.py")
        with open(snippet_path, "w") as f:
            f.write(code)
        
        # Try to execute the code
        result = subprocess.run(
            ["python", snippet_path],
            capture_output=True,
            text=True,
            timeout=10
        )
        
        if result.returncode != 0:
            logger.warning(f"Code execution failed:\n{result.stderr}")
            return f"# Code generated with errors\n{code}\n\n# Error:\n{result.stderr}"
        
        logger.info("Code executed successfully")
        return code
    except SyntaxError as e:
        logger.error(f"Syntax error: {str(e)}")
        return f"# Code with syntax error\n{code}\n\n# Error:\n{str(e)}"
    except Exception as e:
        logger.error(f"Validation error: {str(e)}")
        return code