import spacy
from config import Config
from core.utils.logger import logger

# Load the NLP model
try:
    nlp = spacy.load(Config.NLP_MODEL)
    logger.info(f"Loaded NLP model: {Config.NLP_MODEL}")
except OSError:
    logger.warning(f"Model {Config.NLP_MODEL} not found. Downloading...")
    spacy.cli.download(Config.NLP_MODEL)
    nlp = spacy.load(Config.NLP_MODEL)

def process_query(text: str):
    """Process text with spaCy NLP pipeline"""
    try:
        doc = nlp(text)
        logger.debug(f"NLP processed: Tokens={[token.text for token in doc]}")
        return doc
    except Exception as e:
        logger.error(f"NLP processing error: {str(e)}")
        raise