from core.utils.logger import logger

INTENTS = {
    "CODE_GENERATION": ["create", "generate", "write", "build", "make"],
    "DEBUGGING": ["debug", "fix", "error", "issue", "problem"],
    "EXPLANATION": ["explain", "how", "what", "why", "describe"]
}

def detect_intent(doc) -> str:
    """Detect user intent based on processed text"""
    try:
        text = doc.text.lower()
        
        # Check for intent keywords
        for intent, keywords in INTENTS.items():
            if any(keyword in text for keyword in keywords):
                return intent
        
        # Default to code generation if no specific intent found
        return "CODE_GENERATION"
    except Exception as e:
        logger.error(f"Intent detection error: {str(e)}")
        return "CODE_GENERATION"