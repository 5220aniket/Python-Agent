import logging
import os
import sys
from datetime import datetime
from config import Config

def setup_logger():
    """Configure logging system with comprehensive error handling"""
    try:
        # Initialize configuration
        config = Config()
        
        # Create logs directory if it doesn't exist
        os.makedirs(config.LOGS_DIR, exist_ok=True)
        
        # Create logger
        logger = logging.getLogger("CodingAgent")
        logger.setLevel(config.LOG_LEVEL)
        
        # Create formatter
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        
        # File handler
        log_file = os.path.join(
            config.LOGS_DIR, 
            f"agent_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
        )
        file_handler = logging.FileHandler(log_file)
        file_handler.setFormatter(formatter)
        
        # Console handler
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(formatter)
        
        # Add handlers
        logger.addHandler(file_handler)
        logger.addHandler(console_handler)
        
        logger.info("Logger initialized successfully")
        return logger
        
    except Exception as e:
        # Fallback to basic logging if setup fails
        print(f"CRITICAL: Failed to setup logger: {str(e)}")
        fallback_logger = logging.getLogger("FallbackCodingAgent")
        fallback_logger.setLevel(logging.INFO)
        
        # Add console handler as minimum
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(logging.Formatter('%(levelname)s - %(message)s'))
        fallback_logger.addHandler(console_handler)
        
        fallback_logger.error("Using fallback logger due to initialization failure")
        return fallback_logger

# Initialize logger instance
logger = setup_logger()