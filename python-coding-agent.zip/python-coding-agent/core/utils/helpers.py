import hashlib
from datetime import datetime

def generate_session_id(user_input: str) -> str:
    """Generate unique session ID"""
    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
    unique_str = f"{user_input}-{timestamp}"
    return hashlib.md5(unique_str.encode()).hexdigest()

def safe_execute(code: str) -> str:
    """Safely execute Python code"""
    try:
        exec_globals = {}
        exec(code, exec_globals)
        return "Code executed successfully"
    except Exception as e:
        return f"Execution error: {str(e)}"