from core.modules.input_parser import parse_input
from core.modules.nlp_processor import process_query
from core.modules.intent_detector import detect_intent
from core.modules.code_generator import generate_code
from core.modules.validator import validate_code
from core.modules.formatter import format_output
from core.utils.logger import logger

def handle_task(user_query: str) -> str:
    logger.info(f"Handling task: {user_query}")
    
    try:
        # Step 1: Input Parsing
        cleaned_input = parse_input(user_query)
        
        # Step 2: NLP Processing
        processed = process_query(cleaned_input)
        
        # Step 3: Intent Recognition
        intent = detect_intent(processed)
        logger.info(f"Detected intent: {intent}")
        
        # Step 4: Code Generation
        raw_code = generate_code(processed, intent)
        
        # Step 5: Code Validation
        validated_code = validate_code(raw_code)
        
        # Step 6: Output Formatting
        formatted_response = format_output(validated_code, intent)
        
        return formatted_response
    except Exception as e:
        logger.error(f"Task handling failed: {str(e)}")
        raise