from core.agents.coding_agent import handle_task

def main():
    print("Python Coding Agent - CLI Mode")
    print("Enter your query (type 'exit' to quit):")
    
    while True:
        user_input = input("\n>>> ")
        if user_input.lower() in ['exit', 'quit']:
            break
        
        try:
            response = handle_task(user_input)
            print("\nResponse:")
            print(response)
        except Exception as e:
            print(f"\nError: {str(e)}")

if __name__ == "__main__":
    main()